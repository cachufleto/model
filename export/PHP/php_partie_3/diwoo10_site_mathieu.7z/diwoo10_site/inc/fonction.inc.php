<?php

// FONCTION DIVERS

function debug($var, $mode = 1)
{
	echo '<div class="col-md-12">';
	if($mode === 1)
	{
		echo '<pre>'; var_dump($var); echo '</pre>';
	}
	else {
		echo '<pre>'; print_r($var); echo '</pre>';
	}
	echo '</div>';
	return;
}

// FONCTION POUR FAIRE DES REQUETES EN BDD


function executeRequete($req) // on doit fournir en argument la requete à exécuter.
{
	global $mysqli; // on précise de récupérer la variable $mysqli (qui représente la connexion à la BDD) depuis l'espace global (voir dans init.inc.php)
	$resultat = $mysqli->query($req); // on exécute la requete reçue en argument.
	
	if(!$resultat) // si cela renvoi false, c'est qu'il y a une erreur sur la requete
	{
		die ("Erreur sur la requete SQL<br /> <b>Message: </b>" . $mysqli->error . "<br /> Requete: ". $req);
	}
	return $resultat;
	
}

// FONCTION MEMBRE

function utilisateurEstConnecte()
{
	if(!isset($_SESSION['utilisateur']))
	{ 
		return false;
	}
	else {// si l'indice utilisateur existe dans la session, alors l'utilisateur est passé par la page connexion et a donné les bons identifiants. Il est donc connecté.
		return true;
	}
}

function utilisateurEstConnecteEtEstAdmin()
{
	if(utilisateurEstConnecte() && $_SESSION['utilisateur']['statut'] == 1) // on vérifie si l'utilisateur est connecté et aussi si son statut est égal à 1
	{
		return true;
	}
	return false;
}

// Controle de l'extension des images provenant du formulaire de la page gestion_boutique

function verificationExtensionPhoto() 
{
	$extension = strrchr($_FILES['photo']['name'], '.'); // permet de retourner le texte contenu après le . en incluant le . 
	// premier argument la chaine de caractères où chercher
	// deuxième argument ce qu'on cherche.
	// strrrchr cherche le deuxième argument en partant de la fin de la chaine.
	$extension = strtolower(substr($extension, 1)); // nous coupons le . et strtolower passe la chaine de caractères en minuscule.
	$tab_extension_valide = array('jpg', 'jpeg', 'png', 'gif'); // on déclare un tableau arrau contenant les extensions acceptées.
	$verif_extension = in_array($extension, $tab_extension_valide); // in_array va vérifier si le premier argument est présent dans les valeurs du deuxième argument (tableau ARRAY) // renvoi true ou false
	
	return $verif_extension; // retourne true ou false !
}











