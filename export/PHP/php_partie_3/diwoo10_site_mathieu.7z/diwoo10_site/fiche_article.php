<?php
require_once("inc/init.inc.php");

if(isset($_GET['id_article']))
{
	$id_article = $_GET['id_article'];
	$resultat = executeRequete("SELECT * FROM article WHERE id_article = '$id_article'");	
	
	if($resultat->num_rows < 1)
	{
		header("location:index.php");
		exit();
	}
	
	$article = $resultat->fetch_assoc();
	
}else {
	header("location:index.php");
	exit();
}



require_once("inc/header.inc.php");
require_once("inc/nav.inc.php");
echo $msg;
 debug($article);

// faire une mise en forme des informations de l'article
// ne pas aficher l'id_article

// faire un formulaire d'ajout au panier
// - choix de la quantité (select)
		// - la liste ne doit pas afficher plus de quantité que le stock de l'article
// bouton de validation 
?>    


      <div class="starter-template">
        <h1><span class="glyphicon glyphicon-thumbs-up"></span> Fiche article</h1>
		<hr />
      </div>
	  
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
    </div><!-- /.container -->
	
<?php
require_once("inc/footer.inc.php");
	
	
	

