<?php
require_once("inc/init.inc.php");



require_once("inc/header.inc.php");
require_once("inc/nav.inc.php");
echo $msg;
?>    


      <div class="starter-template">
        <h1>Montitre</h1>
		<hr />
      </div>
	  
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
    </div><!-- /.container -->
	
<?php
require_once("inc/footer.inc.php");
	
	
	

